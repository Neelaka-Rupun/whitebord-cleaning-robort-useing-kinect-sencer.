﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.IO.Ports;
//using Microsoft.Samples.Kinect.SkeletonBasics.ConnectingRobort

namespace Microsoft.Samples.Kinect.SkeletonBasics.Connecting
{
    class ConnectingRobort
    {

        private SerialPort myport;

        public void Init()
        {  //making the bluetooth connection 
            try
            {
                myport = new SerialPort();
                myport.BaudRate = 9600;
                myport.PortName = "COM5";
                myport.Open();
            }
            catch (Exception e)
            {
                MessageBox.Show("Can't connect the bluetooth prot " );
            }
        }
        public void RobotForward(string useInput)
        {
            myport.WriteLine(useInput); // inputing f to robort
        }
        public void RobotBack(string useInput)
        {
            myport.WriteLine(useInput);// inputing b for back word 
        }
        public void RobotRight(string useInput)
        {
            myport.WriteLine(useInput);//inputing r to turn right
        }
        public void RobotLeft(string useInput)
        {
            myport.WriteLine(useInput);//inputing l to turn leaft

        }
        public void RobortStop(string useInput) // otherwise stop
        {
            myport.WriteLine(useInput);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using Microsoft.Kinect;

namespace Microsoft.Samples.Kinect.SkeletonBasics.Connecting
{
    class ControlRobort
    {

        public void ProcessCommand(Skeleton skeleton, ConnectingRobort bluetooth)
        {
            Joint handRight = skeleton.Joints[JointType.HandRight];
            Joint handLeft = skeleton.Joints[JointType.HandLeft];
            Joint shoulderRight = skeleton.Joints[JointType.ShoulderRight];
            Joint shoulderLeft = skeleton.Joints[JointType.ShoulderLeft];
            Joint hipLeft = skeleton.Joints[JointType.HipLeft];
            Joint hipRight = skeleton.Joints[JointType.HipRight];
            Joint head = skeleton.Joints[JointType.Head];


            if (handRight.Position.X < hipRight.Position.X) // forward function function is working for compairing position of hand and hip 
            {
                Console.WriteLine("f");
                bluetooth.RobotForward("f");
            }
            else if (handLeft.Position.X > hipLeft.Position.X) // backword fuction 
            {
                Console.WriteLine("b");
                bluetooth.RobotBack("b");
            }
            else if (handRight.Position.Y > shoulderRight.Position.Y)
            {
                Console.WriteLine("r");
                bluetooth.RobotRight("r");
            }
            else if (handLeft.Position.Y > shoulderLeft.Position.Y)
            {
                Console.WriteLine("l");
                bluetooth.RobotLeft("l");
            }
            else
            {
                Console.WriteLine("s");
                bluetooth.RobortStop("s");
            }
        }
    }
}

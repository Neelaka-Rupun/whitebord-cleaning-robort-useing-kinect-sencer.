﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Microsoft.Samples.Kinect.SkeletonBasics
{
    /// <summary>
    /// Interaction logic for WhiteBordClener.xaml
    /// </summary>
    public partial class WhiteBordClener : Window
    {
        private MainWindow navigateMainWindow;

        public WhiteBordClener()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            navigateMainWindow = new MainWindow();
            navigateMainWindow.InitializeComponent();
        }
    }
}
